This zip archive contains data files from Cricsheet in JSON format. This
archive contains 12 recently added matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/recently_added_2_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-11-13 - international - T20 - male - 1456868 - Myanmar vs Indonesia
2024-11-13 - international - T20 - male - 1454819 - Netherlands vs Oman
2024-11-13 - international - T20 - male - 1449303 - India vs South Africa
2024-11-13 - international - ODM - male - 1451903 - Uganda vs Italy
2024-11-13 - international - ODM - male - 1451902 - Tanzania vs Singapore
2024-11-13 - international - ODI - male - 1456443 - Sri Lanka vs New Zealand
2024-11-13 - club - WBB - female - 1442670 - Hobart Hurricanes vs Adelaide Strikers
2024-11-12 - international - T20 - male - 1456867 - Indonesia vs Myanmar
2024-11-12 - international - ODM - male - 1451901 - Tanzania vs Hong Kong
2024-11-12 - club - WBB - female - 1442669 - Perth Scorchers vs Sydney Thunder
2024-11-11 - club - PKS - male - 1452138 - Auckland Aces vs Wellington Firebirds
2024-11-11 - club - PKS - male - 1452137 - Otago Volts vs Central Stags
